<?php
$monto = $_GET["monto"];
$formattedMonto = number_format($monto, 2, '.', ',');
date_default_timezone_set('America/Merida');
$correo_pdf = '
<head>
<meta charset="utf-8"/>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

table, td, th {
  border: 1px solid black;
}

th {
  padding: 15px;
  text-align: left;
}
</style>
</head>
<body>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center">
<table class="responsive-table" style="border: 1px solid #d0d0d0;" border="0" width="500" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 40px 20px 30px 20px;" bgcolor="#ffffff">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="padding-copy" style="font-size: 25px; font-family: Helvetica, Arial, sans-serif; color: #333333;" align="center"><img src="https://mdos.mx/assets/logos/Piaro-Azul.png" alt="Piaro" width="220"></td>
</tr>
<tr>
<td class="padding-copy" style="font-size: 22px; font-family: Helvetica, Arial, sans-serif; color: #FFFFFF; background-color: #29305a;" align="center"><br>Recibo de pago<br><br></td>
<!-- <td class="padding-copy" style="font-size: 32px; font-family: Helvetica, Arial, sans-serif; color: #333333;" align="center">Recibo de pago</td> -->
</tr>
<tr>
<td class="padding-copy" style="padding: 20px 0 0 0; font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif; color: #666666;" align="left">&nbsp; &nbsp; Hola <strong>'. $_GET["nombre"] .'</strong> su pago se ha realizado con éxito, abajo le dejo los datos de pago: <br><br></td>
</tr>
<tr>
<td style="padding: 30px 0px 0px; text-align: left;" align="left">
<table border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><p>&nbsp; &nbsp; Cliente:</p></td>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><strong>&nbsp; &nbsp; '. $_GET["nombre"] .'</strong></td>
</tr>
<tr>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><p>&nbsp; &nbsp; Desarrollo:</p></td>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><strong>&nbsp; &nbsp; Piaro </strong></td>
</tr>
<tr>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><p>&nbsp; &nbsp; Tipo Pago:</p></td>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><strong>&nbsp; &nbsp; '. $_GET["tipopago"] .'</strong></td>
</tr>
<tr>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><p>&nbsp; &nbsp; Cantidad recibida:</p></td>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><strong>&nbsp; &nbsp; $' . $formattedMonto. ' MXN</strong></td>
</tr>
<tr>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><p>&nbsp; &nbsp; Número de Lote:</p></td>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;">
<strong>&nbsp; &nbsp; Etapa:</strong>
<strong>'. $_GET["etapa"] .'</strong>
<strong>- Cluster:</strong>
<strong>'. $_GET["cluster"] .'</strong>
<strong>- Lote:</strong>
<strong>'. $_GET["lote"] .'</strong>
</td>
</tr>
<tr>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><p>&nbsp; &nbsp; Fecha:</p></td>
<td style="font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif;"><strong>&nbsp; &nbsp; '. date('d/m/Y H:i:s'). '</strong></td>
</tr>
</tr>
</tbody>
</table>
</tbody>
</table>
</tbody>
</table>
<br><br>
<div style="text-align: center;">
  <img src="https://mdos.mx/assets/logos/logo-eme-dos-desarrollos.png" width="200">
</div>
<p style="text-align: center;">
  <strong><em>Este documento no tiene carácter oficial y únicamente se proporciona con fines de lectura informativa.</em></strong>
</p>
';

