console.log('Netpay setup');

const urlCheckOut = "https://suite.netpay.com.mx/gateway-ecommerce/v3.2/checkout/session/";

const paramsDataNetpay = {
	"successUrl": "https://fibrax.mx/central-de-pagos-test/",
	"cancelUrl": "https://fibrax.mx/central-de-pagos-test/",
	"customerEmail": "accept@netpay.com.mx",
	"customerName": "Jon Doe",
	"paymentMethodTypes": ["card"],
    "merchantRefCode": Date.now().toString(36) + Math.random().toString(36).substr(2),
	"lineItems": [],
    "linkType": "NETPAY_CHECKOUT"
};

const headersNetpay = {
	'Content-Type': 'application/json',
	'Authorization': 'sk_netpay_qlQsYsDwBHsYOfbXvSzJZYEixaCdOniucQyNvCFTgCbWJ'
};


const netpayBtn = document.getElementById('netpay_btn');

netpayBtn.addEventListener("click",(evt)=>{
	
	paramsDataNetpay["customerEmail"] = document.getElementById("cardholder-email").value;
	paramsDataNetpay["customerName"] = document.getElementById("cardholder-name").value;
	paramsDataNetpay["customerPhone"] = document.getElementById("cardholder-phone").value;
	paramsDataNetpay["merchantRefCode"] = Date.now().toString(36) + Math.random().toString(36).substr(2);
	paramsDataNetpay["lineItems"] = [];
	paramsDataNetpay["lineItems"].push(
		{
			"name": this.generateName(),
			"quantity": 1,
			"amount": document.getElementById("montofinal").value,
			"currency":  "MXN"
		}
	);
	
	paramsDataNetpay["installments"] = 	{
     	"plan": {
          "count": 6,
          "interval": "month",
          "promotion": "000603"
    	}
  	};
	//
	// console.log(paramsDataNetpay);d
	generateNetpayLink();
});

function generateNetpayLink(){
		console.log(JSON.stringify(paramsDataNetpay));
		//return; 
		fetch(urlCheckOut, {
			method:'POST',
			body: JSON.stringify(paramsDataNetpay),
			headers: headersNetpay
		}).then(res=>res.json()).then((data) => {
			console.log(data);
			if(data.hostedCheckoutUrl === undefined) {
					Swal.fire({
					  icon: 'error',
					  title: 'Algo salio mal',
					  text: 'Verifica que todos los campos esten llenos, Todos son obligatorios, el campo de monto es muy importante'
					})
					return;
			}
			
			window.location.href = data.hostedCheckoutUrl;
			
		}).catch((error)=>{
			alert('Algo salió mal, intentalo más tarde');
			console.log("error: " + error);
		});
}


function generateName(){

	let name = "";
	let tipopago = document.getElementById("tipoPagoList");
	let desarrolloSel = document.getElementById("nlote");
	
	if(""+tipopago.value !== "0") {
		name+=(tipopago.options[tipopago.selectedIndex].text);
	}  
	
	if(""+desarrolloSel.value !== "0") {
		name += (" para " + desarrolloSel.options[desarrolloSel.selectedIndex].text);
	}
	
	return name;
	
}