console.log('Ejecutando');


const btndiferir = document.getElementById("diferir");
btndiferir.addEventListener('click', (e) => {

    if (!$('#cardholder-email-confirm').val()) {
        alert('Ingresa tu correo electronico');
        return;
    }

    let idprod = null;

    if (['3', '4', '9'].includes($('#des').val())) {
        idprod = "price_1K4VrYDATtHIPsEJpeeVqZc1";
    } else {
        idprod = "price_1K4Vq9DATtHIPsEJ5uTMlKWV";
    }

    fetch('https://gpi-crm.herokuapp.com/gateway/stripe_subscription',
        {
            method: 'POST',
            body: JSON.stringify({
                "Email": $('#cardholder-email').val(),
                "Descripcion": "Gasto administrativo",
                "Titulo": "Gasto administrativo",
                "Total": 5499,
                "Desarrollo": "5",
                "Cantidad": 1,
                "IdProducto": idprod
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(res => res.json())
        .then((res) => {
            if (res.error !== true) {
                window.location.href = res.url;
            }
        });

})
