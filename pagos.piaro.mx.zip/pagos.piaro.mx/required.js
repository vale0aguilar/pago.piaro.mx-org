function required() {
    var inputs = document.getElementsByTagName("input");
    var isValid = true;

    for (var i = 0; i < inputs.length; i++) {
      if (inputs[i].hasAttribute("required") && inputs[i].value.trim() === "") {
        isValid = false;
        break;
      }
    }

    if (!isValid) {
      alert("Por favor, complete todos los campos obligatorios.");
      return false;
    }
  }