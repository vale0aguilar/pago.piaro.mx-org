<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
//API PRODUCCION
//$stripeSecretKey = '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';

//API TEST
$stripeSecretKey = 'sk_test_51JrmXyKEhU8YMMgG5OeeXwSQEAwblXsTZQt5r1Ret8AKuPrFPYOZfojlVWrbt5IcbP686rDUwK8wEeB3To4BDnfp00D9WbV9It';