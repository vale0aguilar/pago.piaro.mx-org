<?php
$email = $_GET['email'];
$monto = $_GET["monto"];
$formattedMonto = number_format($monto, 0, ',', ',');


//DomPDF 
use Dompdf\Dompdf;
use Dompdf\Options;

require 'vendor/autoload.php';
include ('template.php');
include ('TemplatePdf.php');

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);

$dompdf->load_html($correo_pdf);
$dompdf->render();
$pdf_content = $dompdf->output();

//Envio de correos
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

ob_start(); // Iniciar el almacenamiento de salida en búfer

$mail = new PHPMailer(true);
try {
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->Host = 'mail.piaro.mx';
    $mail->SMTPAuth = true;
    $mail->Username = 'pagos@piaro.mx'; //Se pone el correo que envia el mensaje
    $mail->Password = '3D@Ncmy-_NnY';//La contraseña del correo, este permite acceder y enviar los correos
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 26;

    //Adjuntamos el pdf
    $mail->addStringAttachment($pdf_content, 'Pago_Recibido.pdf');

    $mail->setFrom('pagos@piaro.mx', 'Prueba correo'); //Se pone el correo que envia el mensaje
    $mail->addAddress($email, 'Receptor'); //Se ingresa el correo a que deberia llegarle
    $mail->addCC('ti@mdos.mx');
    $mail->addCC('pagos@mdos.mx');
    $mail->addCC('r.canche@mdos.mx');
    $mail->addCC('j.dominguez@mdos.mx');
    $mail->addCC('coordinacion.comercial@mdos.mx');

    $mail->isHTML(true);
    $mail->Subject = 'Prueba desde GMAIL';
    $mail->Body = $mensaje_correo; //Se envia un titulo
    $mail->send();

    echo 'Correo enviado';
} catch (Exception $e) {
    echo 'Mensaje ' . $mail->ErrorInfo;
}

$output = ob_get_contents(); // Obtener la salida generada
ob_end_clean(); // Limpiar el búfer

error_log($output); // Enviar la salida a la consola o al archivo de registro de error
?>


<!DOCTYPE html>
<html>
<head>
  <title>Gracias por su compra!</title>
  <link rel="stylesheet" href="style.css">
</head>
<style>
  .container {
  display: flex;
  justify-content: center;
  align-items: center;
}

.content {
  text-align: center;
}

</style>
<body>
<section class="container">
  <div class="content">
    <label>
      Muchas gracias por su pago en Piaro,<br>
      el comprobante ha sido enviado a su correo electrónico,<br>
      cualquier duda, contacte el siguiente correo:<br>
      <a href="mailto:ayuda@piaro.mx">ayuda@piaro.mx</a>.<br>
      Nombre Completo: <?php isset($_GET["nombre"]) ? print $_GET["nombre"] : ""; ?><br>
      Email: <?php isset($_GET["email"]) ? print $_GET["email"] : ""; ?><br>
      Tipo pago: <?php isset($_GET["tipopago"]) ? print $_GET["tipopago"] : ""; ?><br>
      Lote: <?php isset($_GET["lote"]) ? print $_GET["lote"] : ""; ?><br>
      Cluster: <?php isset($_GET["cluster"]) ? print $_GET["cluster"] : ""; ?><br>
      Etapa: <?php isset($_GET["etapa"]) ? print $_GET["etapa"] : ""; ?><br>
      Total Pagado: $ <?php echo $formattedMonto, ' MXN' ?>
    </p>
  </section>
</body>
</html>