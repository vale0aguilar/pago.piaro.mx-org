<?php
$monto = $_GET["monto"];
$formattedMonto = number_format($monto, 2, '.', ',');
date_default_timezone_set('America/Merida');

$mensaje_correo = '
<meta charset="utf-8"/>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center">
<table class="responsive-table" style="border: 1px solid #d0d0d0;" border="0" width="500" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 40px 20px 30px 20px;" bgcolor="#ffffff">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="padding-copy" style="font-size: 32px; font-family: Helvetica, Arial, sans-serif; color: #333333;" align="center"><img src="https://mdos.mx/assets/logos/Piaro-Azul.png" alt="Piaro" width="450"></td>
</tr>
<tr>
<td class="padding-copy" style="font-size: 32px; font-family: Helvetica, Arial, sans-serif; color: #333333;" align="center">Prueba de pago</td>
<!-- <td class="padding-copy" style="font-size: 32px; font-family: Helvetica, Arial, sans-serif; color: #333333;" align="center">Recibo de pago</td> -->
</tr>
<tr>
<td class="padding-copy" style="padding: 20px 0 0 0; font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif; color: #666666;" align="left">Hola <strong>'. $_GET["nombre"] .'</strong> su pago se ha realizado con éxito, abajo le dejo los datos de pago:</td>
</tr>
<tr>
<td style="padding: 30px 0px 0px; text-align: left;" align="left">
Cliente: <strong>'. $_GET["nombre"] .'</strong><br>
Desarrollo:<strong> Piaro </strong><br>
Tipo Pago: <strong>'. $_GET["tipopago"] .'</strong><br>
Cantidad recibida:<strong> $' . $formattedMonto. ' MXN</strong><br>
Número de Lote: <strong> Etapa: </strong> <strong>'. $_GET["etapa"] .'</strong><strong> - Cluster:</strong> <strong>'. $_GET["cluster"] .'</strong><strong> - Lote:</strong> <strong>'. $_GET["lote"] .'</strong><br>
Fecha: <strong> '. date('d/m/Y H:i:s'). '</strong>
</td>    
</td>
</tr>
<tr>
<td class="padding-copy" style="padding: 20px 0 0 0; font-size: 16px; line-height: 25px; font-family: Helvetica, Arial, sans-serif; color: #666666;" align="left">&nbsp; &nbsp; Por cualquier duda o aclaracion puede mandarnos un mensaje.</td>
</tr>
<tr>
<td align="center">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="padding" style="padding: 25px 0 5px 0;" align="center">
<table class="mobile-button-container" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="border-radius: 3px;" align="center" bgcolor="#18a689"><a class="mobile-button" style="font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 3px; padding: 15px 25px; border: 1px solid #18a689; display: inline-block;" href="https://wa.me/+5219992587886?text=Hola,%20necesitio%20ayuda%20en" target="_blank" rel="noopener">Soporte de pagos M2</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding: 0px 0px 0px; text-align: center;">

<hr />

Pago realizado desde pagos.mdos.mx<br /> </td>
</tr>
<tr>
<td class="padding-copy" style="font-size: 32px; font-family: Helvetica, Arial, sans-serif; color: #333333;" align="center"><img src="https://mdos.mx/assets/logos/logo-eme-dos-desarrollos.png" alt="Piaro" width="250" ></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
';

