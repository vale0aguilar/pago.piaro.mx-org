<?php
// This is the URL you should configure in your Stripe Dashboard
$webhookEndpoint = 'https://your-domain.com/webhook.php';

// Handle the incoming webhook event
$payload = @file_get_contents('php://input');
$event = json_decode($payload, true);

// Handle the payment success event
if ($event['type'] === 'checkout.session.completed') {
    $checkoutSession = $event['data']['object'];
    
    // Envío de correo code here
    $url = 'https://gpi-crm.herokuapp.com/emails/Piaro';
    $data = [
        'nombre' => $checkoutSession['customer_details']['name'],
        'tipopago' => $checkoutSession['metadata']['tipopago'],
        'tot' => $checkoutSession['metadata']['montofinal'],
        'lote' => $checkoutSession['metadata']['lote'],
        'cluster' => $checkoutSession['metadata']['cluster'],
        'etapa' => $checkoutSession['metadata']['etapa'],
        'email' => $checkoutSession['customer_details']['email'],
    ];

}
